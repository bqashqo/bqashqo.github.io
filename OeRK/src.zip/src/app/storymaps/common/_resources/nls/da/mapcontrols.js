define({
  "commonMapControls": {
    "common": {
      "settings": "Indstillinger",
      "openDefault": "Åbn som standard"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Baggrundskort",
      "expandFactorLabel": "Udvidelsesfaktor",
      "expandFactorPopover": "Forholdet mellem størrelsen af oversigtskortet og udstrækningen af det rektangel, der vises på oversigtskortet. Standardværdien er 2, hvilket betyder, at oversigtskortet vil være mindst dobbelt så stort som rektangeludstrækningen."
    }
  }
});