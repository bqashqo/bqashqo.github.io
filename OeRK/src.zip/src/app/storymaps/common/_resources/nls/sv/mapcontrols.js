define({
  "commonMapControls": {
    "common": {
      "settings": "Inställningar",
      "openDefault": "Öppen som standard"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Baskarta",
      "expandFactorLabel": "Expanderingsfaktor",
      "expandFactorPopover": "Förhållandet mellan översiktskartans storlek och utbredningsrektangeln som visas på översiktskartan. Standardvärdet är 2, vilket innebär att översiktskartan är minst dubbelt så stor som utbredningsrektangeln."
    }
  }
});