define({
  "commonMapControls": {
    "common": {
      "settings": "Thiết lập",
      "openDefault": "Mở theo mặc định"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Bản đồ nền",
      "expandFactorLabel": "Hệ số Mở rộng",
      "expandFactorPopover": "Tỷ lệ giữa kích cỡ của bản đồ toàn cảnh và hình chữ nhật kéo dài hiển thị trên bản đồ toàn cảnh. Giá trị mặc định là 2, có nghĩa là bản đồ toàn cảnh sẽ gấp ít nhất hai lần kích thước của hình chữ nhật kéo dài."
    }
  }
});