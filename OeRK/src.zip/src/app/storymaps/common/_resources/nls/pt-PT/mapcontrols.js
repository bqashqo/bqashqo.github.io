define({
  "commonMapControls": {
    "common": {
      "settings": "Configurações",
      "openDefault": "Abrir por defeito"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Mapa Base",
      "expandFactorLabel": "Expandir Fator",
      "expandFactorPopover": "O rácio entre o tamanho do mapa de vista geral e o retângulo de extensão exibido no mapa de vista geral. O valor por defeito é 2, o que significa que o mapa de vista geral terá pelo menos duas vezes menos o tamanhodo retângulo de extensão."
    }
  }
});